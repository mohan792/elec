package com.example.demo;

// public class HelloWorldController {

// }

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ElectricityBillController {
    @RequestMapping("/")
    public double hello() {
        // return "Hello User";
        int units = 15;
        if (units <= 50) {
            return units * 3.5;
        }
        else if (units <= 150) {
            return (50 * 3.50)
                + (units - 50)
                      * 4.00;
        }
        else if (units <= 250) {
            return (50 * 3.50)
                + (100 * 4.00)
                + (units - 150)
                      * 5.20;
        }
        else if (units > 250) {
            return (50 * 3.50)
                + (100 * 4.00)
                + (100 * 5.20)
                + (units - 250)
                      * 6.50;
        }
        return 0;
    }
}



